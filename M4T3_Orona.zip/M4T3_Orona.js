//*March 8, 2018
//WEB - 151
//Miguel Ivan Orona

JS> fd(100)
JS> rt(160)
JS> fd(70)
JS> lt(140)
JS> fd(70)
JS> rt(155)
JS> fd(100)
JS> penup()
JS> lt(90)
JS> fd(40)
JS> pendown()
JS> function square() {
  for (var i=1; i <= 4; i++) {
    fd(50)
    lt(90)
  }
}
square()

